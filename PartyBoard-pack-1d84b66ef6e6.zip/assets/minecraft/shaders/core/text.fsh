#version 330

// PartyBoard：バニラ 26.2 の core/text に「場面転換」を足したもの（text.vsh を参照）。

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
flat in int pbMode;
flat in vec2 pbAspect;
in vec2 pbScreen;

out vec4 fragColor;

const vec3 PB_NIGHT = vec3(43.0, 33.0, 64.0) / 255.0;   // outline #2B2140
const vec3 PB_SHADE = vec3(74.0, 59.0, 107.0) / 255.0;  // shade   #4A3B6B
const vec3 PB_GOLD  = vec3(255.0, 212.0, 71.0) / 255.0; // yellow  #FFD447

// 星形の距離（中心からの「星の半径」で割った値。1 が星の縁）
float starShape(vec2 p) {
    float a = atan(p.y, p.x) + 1.5708;
    float k = 6.28318 / 5.0;
    float m = abs(mod(a, k) - k * 0.5) / (k * 0.5);  // 0 = 先端の向き, 1 = くぼみの向き
    float r = mix(1.0, 0.5, m);
    return length(p) / r;
}

vec4 transition(int mode, float t) {
    vec2 aspect = pbAspect;
    vec2 p = pbScreen * aspect;                  // 縦が -1..1 の座標
    // 背景：夜色に小さなひし形の模様
    vec2 cell = fract(gl_FragCoord.xy / 48.0) - 0.5;
    float diamond = step(abs(cell.x) + abs(cell.y), 0.12);
    vec3 bg = mix(PB_NIGHT, PB_SHADE, diamond * 0.6);
    float maxR = length(aspect) + 0.05;
    if (mode == 0) {
        return vec4(bg, t);
    }
    if (mode == 3) {
        // 斜めの帯が左から右へ埋まっていく
        float d = (pbScreen.x + pbScreen.y * 0.35) * 0.5 + 0.5;  // 0..1
        float band = fract(gl_FragCoord.y / 64.0) * 0.12;
        float edge = t * 1.25 - band;
        if (d > edge) discard;
        float rim = smoothstep(edge - 0.02, edge, d);
        return vec4(mix(bg, PB_GOLD, rim), 1.0);
    }
    float r = (1.0 - t) * maxR * (mode == 2 ? 1.6 : 1.0);
    float d = mode == 2 ? starShape(p) : length(p);
    if (d < r) discard;
    float rim = 1.0 - smoothstep(r, r + 0.035, d);
    return vec4(mix(bg, PB_GOLD, rim), 1.0);
}

void main() {
#ifdef IS_GUI
    if (pbMode >= 0) {
        fragColor = transition(pbMode, vertexColor.a);
        return;
    }
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
