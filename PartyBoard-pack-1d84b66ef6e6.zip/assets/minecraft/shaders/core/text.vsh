#version 330

// PartyBoard：バニラ 26.2 の core/text に「場面転換」を足したもの。
// 文字色が (254, 1, 種類) の文字（タイトルで出す）だけを画面全体の四角に引き伸ばす。
// 種類は青の値：0 フェード / 1 丸く閉じる / 2 星形に閉じる / 3 ひし形の帯。不透明度はタイトルのフェードそのもの。

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
flat out int pbMode;
flat out vec2 pbAspect;
out vec2 pbScreen;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    pbMode = -1;
    pbScreen = vec2(0.0);
    pbAspect = vec2(1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c.r == 254 && c.g == 1 && c.b < 8) {
        // 四角の4頂点を画面の四隅へ
        int corner = gl_VertexID % 4;
        vec2 p = corner == 0 ? vec2(-1.0, 1.0) : corner == 1 ? vec2(-1.0, -1.0) : corner == 2 ? vec2(1.0, -1.0) : vec2(1.0, 1.0);
        gl_Position = vec4(p, 0.0, 1.0);
        pbScreen = p;
        pbMode = c.b;
        // GUI の正射影から画面の縦横比を求める（幅/高さ）
        pbAspect = vec2(abs(ProjMat[1][1] / ProjMat[0][0]), 1.0);
    }
#endif
}
